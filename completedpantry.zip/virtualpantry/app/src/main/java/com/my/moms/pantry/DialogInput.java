package com.my.moms.pantry;

public class DialogInput {
}
