package com.my.moms.pantry;

import androidx.fragment.app.DialogFragment;

public class MyDialog extends DialogFragment {

}
