package com.support.android.designlibdemo;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;
import androidx.appcompat.widget.Toolbar;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager.widget.ViewPager;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.yarolegovich.lovelydialog.LovelyCustomDialog;
import com.yarolegovich.lovelydialog.LovelySaveStateHandler;
import com.yarolegovich.lovelydialog.LovelyTextInputDialog;

import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

    private String mUsername;
    private String mPhotoUrl;
    private SharedPreferences mSharedPreferences;
    private GoogleSignInClient mSignInClient;
    private static final String MESSAGE_URL = "http://pantryapp.firebase.google.com/message/";
    public static final String ANONYMOUS = "anonymous";
    public static final String FOODS_CHILD = "foods";
    private EditText editText, etd;
    private Button button;
    private RecyclerView recyclerView;
    private LinearLayoutManager linearLayoutManager;
    private FirebaseRecyclerAdapter adapter;


    //This can be any numbers. R.id.* were chosen for simplicity of example

    private static final int ID_TEXT_INPUT_DIALOG = R.id.fab;


    private LovelySaveStateHandler saveStateHandler;

    private DrawerLayout mDrawerLayout;
    private TextInputEditText mName, mQuantity, mLifecycle;


    // Firebase instance variables
    private FirebaseAuth mFirebaseAuth;
    private FirebaseUser mFirebaseUser;
    private DatabaseReference mFirebaseDatabaseReference;

    EditText name, quantity, lifecycle;
    String n, l,q;
    Foods food = new Foods();

    //View view = LayoutInflater.inflate(R.layout.item_donate_option, null);





    FirebaseDatabase database = FirebaseDatabase.getInstance();
    private DatabaseReference mRef = database.getReference("foods");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        saveStateHandler= new LovelySaveStateHandler();

        View view = getLayoutInflater().inflate(R.layout.item_donate_option, null);
        name =  (EditText) view.findViewById(R.id.item_name);
        quantity = (EditText) view.findViewById(R.id.item_quantity);
        lifecycle = (EditText) view.findViewById(R.id.item_lifecycle);











        //remove below if it breaks
        mSharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);


//         Set default username as anonymous.
        mUsername = ANONYMOUS;

        // Initialize Firebase Auth
        mFirebaseAuth = FirebaseAuth.getInstance();
        mFirebaseUser = mFirebaseAuth.getCurrentUser();
        if (mFirebaseUser == null) {
            // Not signed in, launch the Sign In activity
            startActivity(new Intent(this, SignInActivity.class));
            finish();
            return;
        } else {
            mUsername = mFirebaseUser.getDisplayName();
            if (mFirebaseUser.getPhotoUrl() != null) {
                mPhotoUrl = mFirebaseUser.getPhotoUrl().toString();
            }
        }


        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        final ActionBar ab = getSupportActionBar();
        ab.setHomeAsUpIndicator(R.drawable.ic_menu);
        ab.setDisplayHomeAsUpEnabled(true);

        //new child entries
        mFirebaseDatabaseReference = FirebaseDatabase.getInstance().getReference();

        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawer_layout);

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        if (navigationView != null) {
            setupDrawerContent(navigationView);
        }

        ViewPager viewPager = (ViewPager) findViewById(R.id.viewpager);
        if (viewPager != null) {
            setupViewPager(viewPager);
        }

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);

        fab.setOnClickListener(new View.OnClickListener() {
                                   @Override
                                   public void onClick(View view) {
                                       showLovelyDialog(view.getId(), null);
                                       Snackbar.make(view, "Add a ", Snackbar.LENGTH_LONG)
                                               .setAction("Action", null).show();
                                   }
                               });
        //old version
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Add a ", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(viewPager);
        dbUpdate(food);
    }

//    public class generateDialog extends Dialog {
//
//        public GenerateDialog(@NonNull Context context){
//            super(context, android.R.style.Theme_NoTitleBar_Fullscreen);
//            setContentView(R.layout.fragment_edit_name);
//        }
//
//    }

    public void showLovelyDialog(int savedDialogId, Bundle savedInstanceState){
        showTextInputDialog(savedInstanceState);
    }



    private void showEditDialog(){

        LayoutInflater li = LayoutInflater.from(getApplicationContext());
        final View promptsView = li.inflate(R.layout.item_donate_option, null);


//        final EditText mText = new EditText(R.id.item_name);
//        final View view = LayoutInflater.inflate(R.layout.item_donate_option);
//        final EditText mText = (EditText) view.findViewById(R.id.item_name);

//        FragmentManager fm = getSupportFragmentManager();
//        EditNameDialogFragment editNameDialogFragment = EditNameDialogFragment.newInstance("Add Item");
//        editNameDialogFragment.show(fm, "fragment_edit_name");

        final EditText name = (EditText) promptsView.findViewById(R.id.item_name);
        final LovelyCustomDialog mDialog = new LovelyCustomDialog(this, R.style.EditTextTintTheme);

        mDialog.setView(R.layout.item_donate_option);
        mDialog.setTopColorRes(R.color.PINK);
        mDialog.setTitle(R.string.text_input_title);
//                .setMessage(R.string.text_input_message)
        mDialog.setIcon(R.drawable.ic_forum);
        mDialog.show();

        mDialog.setListener(R.id.ld_btn_yes, new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        view = getLayoutInflater().inflate(R.layout.item_donate_option, null);
                        EditText name = (EditText) promptsView.findViewById(R.id.item_name);

//                        Snackbar.make(view, "Added "+name.getText().toString(), Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
                        //Toast.makeText(getApplicationContext(), "Entered: "+ name.getText().toString(), Toast.LENGTH_LONG).show();
                        Foods food = new Foods(name.getText().toString(), "1", "2");
                        mRef.setValue(food);

                        //view = getLayoutInflater().inflate(R.layout.item_donate_option, null);
//                        name = (EditText) view.findViewById(R.id.item_name);
//                        quantity = (EditText) view.findViewById(R.id.item_quantity);
//                        lifecycle = (EditText) view.findViewById(R.id.item_lifecycle);
//
//                        n = name.getText().toString();
//                        q = quantity.getText().toString();
//                        l = name.getText().toString();
//                        food = new Foods(n, q, l);
//                        food.setmName(n);
//                        food.setmQuantity(q);
//                        food.setmLifecycle(l);
//
//
//
//                        Toast.makeText(getApplicationContext(), "Entered: "+ name.getText().toString(), Toast.LENGTH_LONG).show();
//
//







//                        String mN = name.getText().toString();
//                        String mQ= quantity.getText().toString();

//                        TextInputLayout lName = view.findViewById(R.id.name_text_input_layout);
//                        TextInputEditText name = (TextInputEditText) lName.findViewById(R.id.item_name);
//                        String mName = name.getEditText().getText().toString();

//                        databaseHandler(v);


//                        v = getLayoutInflater().inflate(R.layout.item_donate_option, null);
//
//                        TextInputEditText mName = v.findViewById(R.id.item_name);
//                        TextInputEditText mQuantity = v.findViewById(R.id.item_quantity);
//                        TextInputEditText mLifecycle = v.findViewById(R.id.item_lifecycle);


//                        mName = (TextInputEditText)v.findViewById(R.id.item_name);
//                        mQuantity = (TextInputEditText)v.findViewById(R.id.item_quantity);
//                        mLifecycle = (TextInputEditText)v.findViewById(R.id.item_lifecycle);

//                        String mN = mName.getText().toString();
//                        String mQ = mQuantity.getText().toString();
//                        String mL = mLifecycle.getText().toString();

//                        TextInputLayout name = view.findViewById(R.id.item_name);
//                        String mN = mName.getEditText().getText().toString().trim();
//
//                        TextInputLayout quantity = view.findViewById(R.id.item_quantity);
//                        String mQ = quantity.getEditText().getText().toString().trim();
//
//                        TextInputLayout life = view.findViewById(R.id.item_lifecycle);
//                        String mL = life.getEditText().getText().toString().trim();

//                        Foods food = new Foods(mN, mQ, mL);
//                        mRef.child(mN).setValue(food);

//                        writeNewFood();
//                        mName.setText("");
//                        mQuantity.setText("");
//                        mLifecycle.setText("");
                        mDialog.dismiss();
                    }
                });









//                .configureView(/* ... */)
//                .setListener(R.id.ld_btn_yes, /* ... */)
//                .setInstanceStateManager(/* ... */)
//                .setListener(R.id.btn_confirm, new View.OnClickListener(){
//                    @Override
//                    public void onClick(View view) {
//                        mEdit   = (EditText)findViewById(R.id.item_name);
//                        Log.v("EditText", mEdit.getText().toString());
//                    }
//                })

    }

//    public void databaseHandler5(View view){
//        view = getLayoutInflater().inflate(R.layout.item_donate_option, null);
//        TextInputLayout name = view.findViewById(R.id.name_text_input_layout);
//        TextInputEditText mName = view.findViewById((R.id.item_name));
//        String mN = name.getEditText().getText().toString();
//        mRef.setValue(mN);

//        TextInputEditText mQuantity = view.findViewById((R.id.item_name));
//        TextInputEditText mLifecycle = view.findViewById((R.id.item_name));
//
//        String mN = mName.getText().toString();
//        String mQ= mName.getText().toString();
//        String mL = mName.getText().toString();
//
//        Foods food = new Foods(mN, mQ, mL);
//        mRef.child(mN).setValue(food);

//    }

    public void dbUpdate(Foods food){
        mRef.child("food item").setValue(food);
    }
    public void databaseHandler(View v){
        //view = getLayoutInflater().inflate(R.layout.item_donate_option, null);
//
//        EditText mName = view.findViewById((R.id.item_name));

//        View view = getLayoutInflater().inflate(R.layout.item_donate_option, null, false);
//        String mN = ((EditText) view.findViewById(R.id.item_name)).getText.toString();




        //View view = getLayoutInflater().inflate(R.layout.item_donate_option, null, false);
//        name = (EditText) view.findViewById(R.id.item_name);
//        quantity = (EditText) view.findViewById(R.id.item_quantity);

        String email = name.getText().toString();
        String password= quantity.getText().toString();



//        String name = ((EditText) view.findViewById(R.id.item_name)).getText().toString();
        mRef.setValue(name);

//        TextInputEditText mQuantity = view.findViewById((R.id.item_name));
//        TextInputEditText mLifecycle = view.findViewById((R.id.item_name));
//
//        String mN = mName.getText().toString();
//        String mQ= mName.getText().toString();
//        String mL = mName.getText().toString();
//
//        Foods food = new Foods(mN, mQ, mL);
//        mRef.child(mN).setValue(food);

    }

//    public void writeNewFood(@NotNull View v) {
//        final View view = View.inflate(this, R.layout.item_donate_option, null);
//        //final View view = getLayoutInflater().inflate(R.layout.item_donate_option, null);
//        final TextInputEditText mQuantity = (TextInputEditText) view.findViewById(R.id.item_quantity);
//        final TextInputEditText mLifecycle = (TextInputEditText) view.findViewById(R.id.item_lifecycle);
//
//        TextInputLayout name = view.findViewById(R.id.name_text_input_layout);
//        String mN = name.getEditText().getText().toString();
//
//        TextInputLayout quantity = view.findViewById(R.id.quantity_text_input_layout);
//        String mQ = quantity.getEditText().getText().toString().trim();
//
//        TextInputLayout life = view.findViewById(R.id.lifecycle_text_input_layout);
//        String mL = life.getEditText().getText().toString().trim();
//
//        mRef.setValue(mQ);

//        final TextInputEditText mName =(TextInputEditText) view.findViewById(R.id.item_name);

//        String mN = mName.getText().toString();
//        String mQ = mQuantity.getText().toString();
//        String mL = mLifecycle.getText().toString();


//        Foods food = new Foods(mN, mQ, mL);
//        mRef.child(mN).setValue(food);

//        mName.setText("");
//        mQuantity.setText("");
//        mLifecycle.setText("");
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.sample_actions, menu);
        return true;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        saveStateHandler.saveInstanceState(outState);
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedState) {
        super.onRestoreInstanceState(savedState);
        if (LovelySaveStateHandler.wasDialogOnScreen(savedState)) {
            //Dialog won't be restarted automatically, so we need to call this method.
            //Each dialog knows how to restore its state
            showLovelyDialog(LovelySaveStateHandler.getSavedDialogId(savedState), savedState);
        }
    }

    private List<DonationOption> loadDonationOptions() {
        List<DonationOption> result = new ArrayList<>();
        String[] raw = getResources().getStringArray(R.array.donations);
        for (String op : raw) {
            String[] info = op.split("%");
            result.add(new DonationOption(info[1], info[0]));
        }
        return result;
    }


    private void showTextInputDialog(Bundle savedInstanceState) {
        new LovelyTextInputDialog(this, R.style.EditTextTintTheme)
                .setTopColorRes(R.color.PINK)
                .setTitle(R.string.text_input_title)
                .setMessage(R.string.text_input_message)
                .setIcon(R.drawable.ic_forum)
                .setInstanceStateHandler(ID_TEXT_INPUT_DIALOG, saveStateHandler)
                .setConfirmButton(android.R.string.ok, new LovelyTextInputDialog.OnTextInputConfirmListener() {
                    @Override
                    public void onTextInputConfirmed(String text) {
                        Toast.makeText(MainActivity.this,"Added "+ text, Toast.LENGTH_SHORT).show();

                    }
                })
//                .setNegativeButton(android.R.string.no, null)
                .setSavedInstanceState(savedInstanceState)
                .show();
    }


    private void showCustomInputDialog(Bundle savedInstanceState){

        new LovelyCustomDialog(this, R.style.EditTextTintTheme)
                .setTopColorRes(R.color.PINK)

                .setTitle("Add Pantry Item")
                .setIcon(R.drawable.ic_forum)
                .setInstanceStateHandler(ID_TEXT_INPUT_DIALOG, saveStateHandler)
                .setListener(R.id.ld_btn_yes, new View.OnClickListener(){
                    @Override
                    public void onClick(View view) {
                        name = (EditText) view.findViewById(R.id.item_name);
                        Log.v("EditText", name.getText().toString());
                        mRef.setValue(name);
                    }
                    })

                    .show();
                }





    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        switch (AppCompatDelegate.getDefaultNightMode()) {
            case AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM:
                menu.findItem(R.id.menu_night_mode_system).setChecked(true);
                break;
            case AppCompatDelegate.MODE_NIGHT_AUTO:
                menu.findItem(R.id.menu_night_mode_auto).setChecked(true);
                break;
            case AppCompatDelegate.MODE_NIGHT_YES:
                menu.findItem(R.id.menu_night_mode_night).setChecked(true);
                break;
            case AppCompatDelegate.MODE_NIGHT_NO:
                menu.findItem(R.id.menu_night_mode_day).setChecked(true);
                break;
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.sign_out_menu:
                mFirebaseAuth.signOut();
                mSignInClient.signOut();
                mUsername = ANONYMOUS;
                startActivity(new Intent(this, SignInActivity.class));
                finish();
                return true;
            default:
                return super.onOptionsItemSelected(item);
            case android.R.id.home:
                mDrawerLayout.openDrawer(GravityCompat.START);
                return true;
            case R.id.menu_night_mode_system:
                setNightMode(AppCompatDelegate.MODE_NIGHT_FOLLOW_SYSTEM);
                break;
            case R.id.menu_night_mode_day:
                setNightMode(AppCompatDelegate.MODE_NIGHT_NO);
                break;
            case R.id.menu_night_mode_night:
                setNightMode(AppCompatDelegate.MODE_NIGHT_YES);
                break;
            case R.id.menu_night_mode_auto:
                setNightMode(AppCompatDelegate.MODE_NIGHT_AUTO_BATTERY);
                break;


        }
        return super.onOptionsItemSelected(item);
    }

//    @Override
//    public boolean onOptionsItemSelected(MenuItem item) {
//        switch (item.getItemId()) {
//            case R.id.sign_out_menu:
//                mFirebaseAuth.signOut();
//                mSignInClient.signOut();
//
//                mUsername = ANONYMOUS;
//                startActivity(new Intent(this, SignInActivity.class));
//                finish();
//                return true;
//            default:
//                return super.onOptionsItemSelected(item);
//        }
//    }

    private void setNightMode(@AppCompatDelegate.NightMode int nightMode) {
        AppCompatDelegate.setDefaultNightMode(nightMode);

        if (Build.VERSION.SDK_INT >= 11) {
            recreate();
        }
    }

    private void setupViewPager(ViewPager viewPager) {
        Adapter adapter = new Adapter(getSupportFragmentManager());
        adapter.addFragment(new PantryListFragment(), "Inventory");
        adapter.addFragment(new PantryListFragment(), "Grocery List");
        viewPager.setAdapter(adapter);
    }

    private void setupDrawerContent(NavigationView navigationView) {
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(MenuItem menuItem) {
                menuItem.setChecked(true);
                mDrawerLayout.closeDrawers();
                return true;
            }
        });
    }

    static class Adapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragments = new ArrayList<>();
        private final List<String> mFragmentTitles = new ArrayList<>();

        public Adapter(FragmentManager fm) {
            super(fm);
        }

        public void addFragment(Fragment fragment, String title) {
            mFragments.add(fragment);
            mFragmentTitles.add(title);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragments.get(position);
        }

        @Override
        public int getCount() {
            return mFragments.size();
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitles.get(position);
        }
    }

    public void alertDialogDemo() {
        // get alert_dialog.xml view
        LayoutInflater li = LayoutInflater.from(getApplicationContext());
        View promptsView = li.inflate(R.layout.alert_dialog, null);

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(
                getApplicationContext());

        // set alert_dialog.xml to alertdialog builder
        alertDialogBuilder.setView(promptsView);

        final EditText userInput = (EditText) promptsView.findViewById(R.id.etUserInput);

        // set dialog message
        alertDialogBuilder
                .setCancelable(false)
                .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // get user input and set it to result
                        // edit text
                        Toast.makeText(getApplicationContext(), "Entered: "+userInput.getText().toString(), Toast.LENGTH_LONG).show();
                    }
                })
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });

        // create alert dialog
        AlertDialog alertDialog = alertDialogBuilder.create();

        // show it
        alertDialog.show();
    }



}




