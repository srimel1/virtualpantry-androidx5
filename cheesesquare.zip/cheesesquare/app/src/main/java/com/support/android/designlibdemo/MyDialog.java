package com.support.android.designlibdemo;

import androidx.fragment.app.DialogFragment;

public class MyDialog extends DialogFragment {

}
