Stephanie Rimel
ID: 001-89-6019

Activities are complete except for firebase data persistance

Instructions
1. Import project into IDE
2. File > Sync Gradle Project
3. Select emulator
4. Run
5. Sign in with Google username and password
6. Use fragment to navigate or drawer
7. To add pantry inventory item, click FloatingActionButton, the pint + button at bottom left
8. Enter the name of your item you wish to add
9. You can click on the Pantry food item to see a detail view.
10.If you wish to add the Pantry Item to your grocery list, either click the FAB in the Item Detail View, or...
11.Navigate the the Grocery List fragment at top of screen, from Grocery List, click the FAB and enter the desired item.


How it works:
Virtual Pantry App
